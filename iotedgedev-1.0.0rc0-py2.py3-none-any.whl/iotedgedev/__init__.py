# -*- coding: utf-8 -*-

"""Top-level package for Azure IoT Edge Dev Tool."""

__author__ = 'Microsoft Corporation'
__email__ = 'vsciet@microsoft.com'
__version__ = '1.0.0-rc0'
__AIkey__ = '95b20d64-f54f-4de3-8ad5-165a75a6c6fe'
