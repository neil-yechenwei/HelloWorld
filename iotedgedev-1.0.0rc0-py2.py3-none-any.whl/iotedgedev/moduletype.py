from enum import Enum


class ModuleType(Enum):
    System = 1
    User = 2
    Both = 3
