See https://github.com/azure/iotedgedev for usage instructions.


